"""
Kamera-Manager für Unkraut-2025 (Mock-Version)
"""
import cv2
import numpy as np
import time
import threading

class CameraManager:
    def __init__(self):
        self.is_streaming = False
        self.current_frame = None
        self.frame_lock = threading.Lock()
        print("📷 Mock-CameraManager initialisiert")
    
    def start_stream(self):
        if not self.is_streaming:
            self.is_streaming = True
            threading.Thread(target=self._mock_stream, daemon=True).start()
            print("📹 Mock-Stream gestartet")
        return True
    
    def stop_stream(self):
        self.is_streaming = False
        print("📹 Stream gestoppt")
    
    def _mock_stream(self):
        while self.is_streaming:
            # Einfaches Mock-Bild
            img = np.zeros((480, 640, 3), dtype=np.uint8)
            img[:] = (0, 100, 0)  # Grün
            
            cv2.putText(img, 'Unkraut-2025 Mock Camera', (50, 240), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.putText(img, time.strftime('%H:%M:%S'), (50, 280), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 1)
            
            with self.frame_lock:
                self.current_frame = img
            
            time.sleep(0.033)  # ~30 FPS
    
    def get_frame(self):
        with self.frame_lock:
            if self.current_frame is not None:
                ret, buffer = cv2.imencode('.jpg', self.current_frame)
                return buffer.tobytes() if ret else b''
        return b''
    
    def capture_image(self, filename=None):
        if filename is None:
            filename = f"capture_{int(time.time())}.jpg"
        
        frame_data = self.get_frame()
        if frame_data:
            filepath = f"data/images/{filename}"
            with open(filepath, 'wb') as f:
                f.write(frame_data)
            return filename
        return None
    
    def adjust_setting(self, setting, value):
        print(f"📷 Mock: {setting} -> {value}")
        return True

# Globale Instanz
camera_manager = CameraManager()
